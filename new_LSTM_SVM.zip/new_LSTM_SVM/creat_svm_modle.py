import pandas as pd
from sklearn.svm import SVC
import pickle


#建svm模型

#读取处理后的特征集
datax=pd.read_csv('train_features.csv')
datay=pd.read_csv('train_labels.csv')
validatax=pd.read_csv('validation_features.csv')
validatay=pd.read_csv('validation_labels.csv')
# feature_svm_columns=[0,11,12]#3
# feature_svm_columns=[0,13,14,15]#4
# feature_svm_columns=[0,5,11,14,15]#5
# feature_svm_columns=[6,11,12,13,14,15]#6
feature_svm_columns=[0,5,11,12,13,14,15]#7
# feature_svm_columns=[0,5,11,12,13,14,15]
# feature_rnn_columns=[0,2,3,4,5,6,15,16]#8
# feature_rnn_columns=[0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]#19
# feature_rnn_columns=[0,2,3,4,5,8,9,10,11,12,13,14,15,16]#14
# feature_rnn_columns=[0,2,3,4,5,8,9,10,14,15,16]#11
# feature_rnn_columns=[0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]#16
# 将数据集拆分为特征和标签
X_train = datax.iloc[:,feature_svm_columns]
X_valid=validatax.iloc[:,feature_svm_columns]
y_train = datay['label']
y_valid=validatay['label']
dfx = pd.DataFrame(X_train)
dfxvalid=pd.DataFrame(X_valid)
# 将 DataFrame 转换为 NumPy 数组
X_train_std = dfx.values
X_valid_std=dfxvalid.values
    # 数据集划分为训练集和测试集
    # X_train, X_test, y_train, y_test  = train_test_split(X, y, test_size=0.3, random_state=0)
    # 数据标准化处理
    # sc = StandardScaler()
    # sc.fit(X_train)
    # X_train_std = sc.transform(X_train)
    # X_test_std = sc.transform(X_test)



import time
start_time=time.time()
# # 训练一个SVM分类器
svm = SVC(kernel='linear', C=1.0)
print("开始训练模型--------------------------------")
svm.fit(X_train_std, y_train)
# svm.fit(X_train_std, y_train, epochs=10, batch_size=8)
print("结束训练-----------------------------------")
end_time=time.time()
# 计算训练时间
training_time = end_time - start_time

# 输出训练时间
print("训练模型的时间：", training_time, "秒")

# 在测试集上评估模型
y_pred = svm.predict(X_valid)
accuracy = svm.score(X_valid, y_valid)
print(f"模型准确率: {accuracy}")
#精确度（Precision）和召回率（Recall）：
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
#
accuracy = accuracy_score(y_valid, y_pred)
print("精确度：", accuracy)
recall = recall_score(y_valid, y_pred)
print("召回率：", recall)
#
# from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
# 打印混淆矩阵
# conf_matrix = confusion_matrix(y_valid, y_pred)
# print("混淆矩阵：\n", conf_matrix)

# 打印分类报告
# class_report = classification_report(y_valid, y_pred)
# print("分类报告：\n", class_report)

# 保存模型
# print("开始保存模型")
# print("---------------------------------")
# #保存模型到文件
# with open('svmModle_21.pickle', 'wb') as f:
#     pickle.dump(svm, f)
# print("保存结束")


