import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from keras.models import Sequential
from keras.layers import LSTM, Dense

# 读取数据集并进行特征缩放
datax=pd.read_csv('train_features.csv')
datay=pd.read_csv('train_labels.csv')
validatax=pd.read_csv('validation_features.csv')
validatay=pd.read_csv('validation_labels.csv')
# feature_rnn_columns=[0,2,3,4,5,6,15,16]
# feature_rnn_columns=[0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]#19
# feature_rnn_columns=[0,2,3,4,5,6,15,16]#8
# feature_rnn_columns=[0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]#19
# feature_rnn_columns=[0,2,3,4,5,8,9,10,11,12,13,14,15,16]#14
# feature_rnn_columns=[0,2,3,4,5,8,9,10,14,15,16]#11
feature_rnn_columns=[0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]#16
X_train = datax.iloc[:,feature_rnn_columns]
X_valid=validatax.iloc[:,feature_rnn_columns]
y_train = datay['label']
y_valid=validatay['label']
    # scaler = StandardScaler()
    # X_scaled = scaler.fit_transform(X)
dfx = pd.DataFrame(X_train)
dfxvalid=pd.DataFrame(X_valid)
# 将 DataFrame 转换为 NumPy 数组
X_train_std = dfx.values
X_valid_std=dfxvalid.values
# 将数据集转换为时间序列格式
time_steps = 1
num_features = 19
X_train_padded = np.pad(X_train_std, ((0, 0), (0, num_features - X_train_std.shape[1])), mode='constant')
X_train_rnn = np.array([X_train_padded[i:i+time_steps] for i in range(len(X_train_padded) - time_steps + 1)])
X_valid_padded = np.pad(X_valid_std, ((0, 0), (0, num_features - X_valid_std.shape[1])), mode='constant')
X_valid_rnn = np.array([X_valid_padded[i:i+time_steps] for i in range(len(X_valid_padded) - time_steps + 1)])
    # time_steps = 1
    # X_train_time = []
    # for i in range(len(X_train_std) - time_steps + 1):
    #   X_train_time.append(X_train_std[i:i+time_steps])
    # X_train_time = np.array(X_train_time)
    #
    # X_valid_time=[]
    # for i in range(len(X_valid_std) - time_steps + 1):
    #     X_valid_time.append(X_valid_std[i:i+time_steps])
    # X_valid_time = np.array(X_valid_time)
# 划分训练集和测试集
# X_train, X_test, y_train, y_test = train_test_split(X_time, y, test_size=0.2, random_state=42)
import time
start_time=time.time()
# 创建LSTM模型
model = Sequential()
model.add(LSTM(units=16, input_shape=(time_steps, X_train_rnn.shape[2])))
model.add(Dense(units=1, activation='sigmoid'))
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# 在训练集上拟合模型
model.fit(X_train_rnn, y_train, epochs=10, batch_size=8)
#将训练数据集 X_train 和 y_train 输入到模型中，
# 使用梯度下降等优化算法对模型进行训练，重复这个过程10次（每次称为一个epoch），
# 每次用32个样本进行训练。

# 提取特征
feature_extractor = Sequential()
feature_extractor.add(model.layers[0])
X_train_features = feature_extractor.predict(X_train_rnn)
X_valid_features = feature_extractor.predict(X_valid_rnn)

print(X_train_features)
print(X_valid_features)

# 对提取的特征进行进一步处理或应用于分类等任务
# Load labels (replace 'your_labels.csv' with the actual file path)
# labels = pd.read_csv('traintime.csv')['label']
# X_train, X_test, y_train, y_test = train_test_split(X_train_features, y_train, test_size=0.2, random_state=42)

# Standardize the data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_features)
X_valid_scaled = scaler.transform(X_valid_features)

# Reshape the features for LSTM input
X_train_reshaped = X_train_scaled.reshape((X_train_scaled.shape[0], 1, X_train_scaled.shape[1]))
X_valid_reshaped = X_valid_scaled.reshape((X_valid_scaled.shape[0], 1, X_valid_scaled.shape[1]))

# Build an LSTM model
model = Sequential()
model.add(LSTM(units=16, input_shape=(X_train_reshaped.shape[1], X_train_reshaped.shape[2])))
model.add(Dense(units=1, activation='sigmoid'))
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train the model
model.fit(X_train_reshaped, y_train, epochs=10, batch_size=8)
# 记录训练结束时间
end_time = time.time()
# 计算训练时间
training_time = end_time - start_time
# 输出训练时间
print("训练模型的时间：", training_time, "秒")
# Evaluate the model
# loss, accuracy = model.evaluate(X_valid_reshaped((X_valid_scaled.shape[0], 1, X_valid_scaled.shape[1])), y_valid)
# print(f"Loss: {loss}, Accuracy: {accuracy}")
#精确度（Precision）和召回率（Recall）：
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
y_pred = model.predict(X_valid_reshaped)
# To this
y_pred = (model.predict(X_valid_reshaped) > 0.5).astype(int)
accuracy = accuracy_score(y_valid, y_pred)
print("精确度：", accuracy)
recall = recall_score(y_valid, y_pred)
print("召回率：", recall)

from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
# 打印混淆矩阵
conf_matrix = confusion_matrix(y_valid, y_pred)
print("混淆矩阵：\n", conf_matrix)

# 打印分类报告
class_report = classification_report(y_valid, y_pred)
print("分类报告：\n", class_report)



# Save the LSTM model
# model.save('lstm_model.h5')
# 保存模型
# print("开始保存模型")
# print("---------------------------------")
# model.save('rnnModel_19.keras')

